﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            float nota1, nota2, nota3, nota4, promedio;
            Console.WriteLine("Ingrese nota 1: ");
            nota1 = float.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese nota 2: ");
            nota2 = float.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese nota 3: ");
            nota3 = float.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese nota 4: ");
            nota4 = float.Parse(Console.ReadLine());

            promedio = (nota1 + nota2 + nota3 + nota4 / 4);

            if (promedio >= 4.0)
            {
                Console.WriteLine("aprobado con nota: {}");
                else
                {
                    Console.WriteLine("reprobado con nota: {}");
                }
                Console.ReadKey();
            }
        }
    }
}
