﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1.v2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float nota, promedio, sumaNota = 0;
            int cantidadNota;

            Console.WriteLine("Ingrese la cantidad de notas:");
            cantidadNota = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i <= cantidadNota - 1; i++)
            {
                Console.WriteLine("Ingrese nota {0}:", i + 1);
                nota = float.Parse(Console.ReadLine());
                sumaNota += nota;
            }

            promedio = sumaNota / cantidadNota;

            if (promedio >= 4.0)
            {
                Console.WriteLine("Aprobado con nota: {0}", promedio);
            }
            else
            {
                Console.WriteLine("Reprobado con nota: {0}", promedio);
            }

            Console.ReadKey();
        }
    }
}