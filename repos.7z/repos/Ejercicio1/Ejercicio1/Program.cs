﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int suma;

            Random random = new Random();
            int[] numeros = new int[5];
            for (int i = 0; i < 5; i++)
            {
                numeros[i] = random.Next(10);
                Console.WriteLine("{0}", numeros[i]);
            }
            suma = 0;
            for (int i = 0; i < 5; i++)
            {
                suma += numeros[i];

            }
            Console.WriteLine("La suma de los elementos del arreglo es: {0} ", suma);
            Console.ReadKey();
        }
    }
}