﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] nombres = new string[5];
            for (int i = 0; i < 5; i++)
            {
                    Console.WriteLine("Ingresa un nombre: ", i + 1, ":");
                    nombres[i] = Console.ReadLine();
                    Console.WriteLine(nombres[i].Length);



            }
            Console.ReadKey();
        }
    }
}