﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int suma;
            int[] numeros = new int[5];


            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingresa los Valores: ", numeros[i]);
                numeros[i] = Convert.ToInt32(Console.ReadLine());

            }
            suma = 0;
            for (int i = 0; i < 5; i++)
            {
                suma += numeros[i];

            }
            Console.WriteLine("La suma de los elementos del arreglo es: {0} ", suma);
            Console.ReadKey();
        }
    }
}